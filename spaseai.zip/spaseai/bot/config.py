﻿BOT_TOKEN = "7579047019:AAF8PsjnLlJLDpjXep8jgp7O4nBzGyyEb1c"  # токен бота
CHANNEL_URL = "https://t.me/linamineshack"  # Ссылка на канал (проверка сабки)
CHANNEL_ID = "-1002225333036"  # id канала. Начинаеться с минуса (проверка сабки)
VERIF_CHANNEL_ID = "-1002502747314"  # айди канала для верификации айдишников, начинается с минуса (чат с айди)
SUPP = "https://t.me/alexakingster01"
ADMIN_ID = 5337556710 #свой айди
#https://t.me/Hon1sorbio - @Hon1sorBio - ищи в Телеграмм
